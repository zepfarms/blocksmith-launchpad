import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero">
        <div className="hero-overlay" />
        <div className="container hero-content">
          <div>
            <p className="hero-kicker">Premium Auto Care • Same-Day Service</p>
            <h1 className="hero-title">
              Keep Your Car
              <span className="hero-highlight"> Running Like New.</span>
            </h1>
            <p className="hero-subtitle">
              From routine oil changes to complete diagnostics, our certified technicians treat every vehicle 
              like it&apos;s their own. Book in minutes, drive with confidence.
            </p>
            <div className="hero-actions">
              <a href="#book-now" className="btn btn-primary">
                Book an Appointment
              </a>
              <Link to="/services" className="btn btn-secondary">
                View Services
              </Link>
            </div>
            <div className="hero-badges">
              <div className="badge">
                <span className="badge-number">1,200+</span>
                <span className="badge-label">Cars Serviced</span>
              </div>
              <div className="badge">
                <span className="badge-number">4.9★</span>
                <span className="badge-label">Customer Rating</span>
              </div>
              <div className="badge">
                <span className="badge-number">24hr</span>
                <span className="badge-label">Turnaround Options</span>
              </div>
            </div>
          </div>
          <div className="hero-card">
            <div className="hero-card-header">
              <h2>Schedule Your Visit</h2>
              <p>Fast, transparent, and reliable service.</p>
            </div>
            <form className="hero-form" id="book-now">
              <label>
                Preferred Service
                <select defaultValue="Full Diagnostic">
                  <option>Full Diagnostic</option>
                  <option>Oil Change</option>
                  <option>Brake Inspection</option>
                  <option>Tires &amp; Alignment</option>
                  <option>Detailing Package</option>
                </select>
              </label>
              <label>
                Name
                <input type="text" placeholder="Alex Driver" />
              </label>
              <label>
                Phone
                <input type="tel" placeholder="(555) 555-5555" />
              </label>
              <label>
                Vehicle (Year, Make, Model)
                <input type="text" placeholder="2021 Tesla Model 3" />
              </label>
              <button type="submit" className="btn btn-primary btn-full">
                Request Appointment
              </button>
              <p className="hero-form-note">
                No payment required to book. We&apos;ll confirm your time by text.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features">
        <div className="section-header">
          <h2>Everything Your Shop Needs in One Place</h2>
          <p>
            Highlight your best services—repairs, detailing, inspections, or sales—with clean visuals that
            convert visitors into booked customers.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card">
            <h3>Full-Service Repair</h3>
            <p>
              Engine diagnostics, brakes, suspension, and more—handled by experienced technicians using
              modern equipment.
            </p>
          </div>
          <div className="feature-card">
            <h3>Maintenance Packages</h3>
            <p>
              Keep customers coming back with scheduled oil changes, fluid checks, and tire rotations.
            </p>
          </div>
          <div className="feature-card">
            <h3>Detailing &amp; Appearance</h3>
            <p>
              Interior and exterior details that make any vehicle feel brand new, inside and out.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-dark">
        <div className="container split">
          <div>
            <h2>Your Story, Told with Style</h2>
            <p>
              Use this template for a neighborhood auto shop, a specialty performance garage, or a boutique 
              car dealership. Swap photos, colors, and copy in Acari within minutes.
            </p>
            <ul className="checklist">
              <li>Showcase featured vehicles or flagship services</li>
              <li>Built-in booking form to capture leads 24/7</li>
              <li>Modern, mobile-first design that looks great anywhere</li>
            </ul>
          </div>
          <div className="highlight-card">
            <p className="highlight-tag">Template Highlight</p>
            <h3>Built for AI Customization</h3>
            <p>
              Every section is written so Acari&apos;s AI can instantly rewrite text for your niche—
              from tire shops to high-end dealers.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
