import React from 'react'

const Services = () => {
  return (
    <section className="section container">
      <div className="section-header">
        <h1>Services &amp; Packages</h1>
        <p>
          Customize this page to match the exact services your shop or dealership offers. 
          Swap pricing, descriptions, and packages using AI in Acari.
        </p>
      </div>

      <div className="services-layout">
        <div className="services-main">
          <h2>Core Services</h2>
          <div className="service-group">
            <div className="service-item">
              <h3>Full Diagnostic</h3>
              <p>
                Comprehensive multi-point inspection with computer diagnostics, road test, and a clear 
                report on what needs attention now vs later.
              </p>
              <p className="service-meta">From $129 • 1–2 hours</p>
            </div>
            <div className="service-item">
              <h3>Oil Change &amp; Fluids</h3>
              <p>
                Synthetic and conventional options available. Includes filter replacement and top-off 
                of essential fluids.
              </p>
              <p className="service-meta">From $79 • ~45 minutes</p>
            </div>
            <div className="service-item">
              <h3>Brake Service</h3>
              <p>
                Pad and rotor replacement, inspections, and brake fluid service to keep stopping power 
                strong and safe.
              </p>
              <p className="service-meta">From $249 • 2–3 hours</p>
            </div>
          </div>

          <h2>Premium Packages</h2>
          <div className="service-group">
            <div className="service-item">
              <h3>Performance Tune-Up</h3>
              <p>
                Ideal for high-mileage or performance vehicles. Includes plugs, filters, diagnostics, 
                and a custom maintenance plan.
              </p>
              <p className="service-meta">From $399</p>
            </div>
            <div className="service-item">
              <h3>Showroom Detail</h3>
              <p>
                Full interior and exterior detail, paint decontamination, and ceramic sealant for 
                long-lasting gloss.
              </p>
              <p className="service-meta">From $299</p>
            </div>
          </div>
        </div>

        <aside className="services-sidebar">
          <div className="sidebar-card">
            <h3>Need a Loaner or Shuttle?</h3>
            <p>
              Add a quick note here about transportation options while a customer&apos;s car is in the shop.
            </p>
          </div>
          <div className="sidebar-card">
            <h3>For Dealerships</h3>
            <p>
              Replace this section with finance options, warranties, or your latest special offers on 
              vehicles in stock.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Services
