import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo">
            <span className="logo-mark">AC</span>
            <span className="logo-text">
              <span className="logo-primary">Acari</span>
              <span className="logo-sub">Auto Studio</span>
            </span>
          </div>
          <p className="footer-text">
            A modern template for auto repair shops, detailers, and dealerships. 
            Customize everything with AI inside Acari.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Shop Info</h4>
          <p className="footer-text">
            123 Performance Way<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Quick Links</h4>
          <ul className="footer-links">
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <a href="#book-now">Book Now</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Acari Auto Studio. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
