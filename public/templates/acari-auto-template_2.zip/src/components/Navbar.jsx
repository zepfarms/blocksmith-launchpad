import React from 'react'
import { Link, NavLink } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="navbar-inner container">
        <Link to="/" className="logo">
          <span className="logo-mark">AC</span>
          <span className="logo-text">
            <span className="logo-primary">Acari</span>
            <span className="logo-sub">Auto Studio</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
        </nav>
        <a href="#book-now" className="nav-cta">
          Book an Appointment
        </a>
      </div>
    </header>
  )
}

export default Navbar
