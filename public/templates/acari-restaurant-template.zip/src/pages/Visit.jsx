import React from 'react'

const Visit = () => {
  return (
    <section className="section container visit-page">
      <div className="section-header">
        <h1>Visit Us</h1>
        <p>
          Make it effortless for guests to find your restaurant, see your hours, and know what to expect 
          when they walk through the door.
        </p>
      </div>

      <div className="visit-layout">
        <div className="visit-card">
          <h2>Location &amp; Parking</h2>
          <p>
            456 Main Street<br />
            Your City, ST 12345
          </p>
          <p>
            Located in the Main Street shopping center next to the theater. Plenty of free parking in the 
            shared lot and curbside pick-up spots out front.
          </p>
          <div className="map-placeholder">
            Map Placeholder – replace with your Google Maps embed.
          </div>
        </div>
        <div className="visit-info">
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Sun–Thu: 11:00am – 10:00pm<br />
              Fri–Sat: 11:00am – 12:00am
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Text: (555) 555-5555<br />
              Email: hello@yourrestaurant.com
            </p>
          </div>
          <div className="info-block">
            <h3>Good to Know</h3>
            <p>
              Family-friendly, full bar, and TVs in the bar area for big games. Patio seating available 
              seasonally—perfect for happy hour.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Visit
