import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-restaurant">
        <div className="hero-overlay" />
        <div className="container hero-content">
          <div>
            <p className="hero-kicker">Neighborhood Grill • Cocktails • Good Times</p>
            <h1 className="hero-title">
              Big Flavor.
              <span className="hero-highlight warm"> Zero Fuss.</span>
            </h1>
            <p className="hero-subtitle">
              Burgers, ribs, sizzling fajitas, and ice-cold drinks—perfect for weeknight dinners, 
              game days, and everything in between.
            </p>
            <div className="hero-actions">
              <a href="#reserve" className="btn btn-primary">
                Reserve a Table
              </a>
              <Link to="/menu" className="btn btn-secondary">
                View Full Menu
              </Link>
            </div>
            <div className="hero-badges">
              <div className="badge">
                <span className="badge-number">Happy Hour</span>
                <span className="badge-label">Mon–Fri • 3–6pm</span>
              </div>
              <div className="badge">
                <span className="badge-number">2-for-1</span>
                <span className="badge-label">Selected Appetizers</span>
              </div>
              <div className="badge">
                <span className="badge-number">Late Night</span>
                <span className="badge-label">Kitchen Open to Midnight</span>
              </div>
            </div>
          </div>
          <div className="hero-card">
            <div className="hero-card-header">
              <h2>Book Your Night Out</h2>
              <p>Quick reservations for small groups and celebrations.</p>
            </div>
            <form className="hero-form" id="reserve">
              <label>
                Date
                <input type="date" />
              </label>
              <label>
                Time
                <input type="time" />
              </label>
              <label>
                Guests
                <input type="number" min="1" max="20" defaultValue="2" />
              </label>
              <label>
                Name
                <input type="text" placeholder="Taylor Guest" />
              </label>
              <label>
                Phone
                <input type="tel" placeholder="(555) 555-5555" />
              </label>
              <button type="submit" className="btn btn-primary btn-full">
                Request Reservation
              </button>
              <p className="hero-form-note">
                We&apos;ll text you to confirm your reservation details.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-restaurant">
        <div className="section-header">
          <h2>Crave-Worthy Favorites</h2>
          <p>
            Highlight your signature dishes, seasonal specials, or family-style platters. 
            Perfect for Chili&apos;s-style casual dining, sports bars, or local grills.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-dish-card">
            <h3>Sizzling Fajitas</h3>
            <p>
              Marinated chicken or steak, grilled peppers and onions, warm tortillas, and all the fixings.
            </p>
            <p className="tagline">Served steaming hot to your table.</p>
          </div>
          <div className="feature-card feature-dish-card">
            <h3>Signature Burgers</h3>
            <p>
              Thick, juicy patties with melty cheese, crispy bacon, and toasted brioche buns.
            </p>
            <p className="tagline">Customize with add-ons, sauces, and sides.</p>
          </div>
          <div className="feature-card feature-dish-card">
            <h3>Shareable Starters</h3>
            <p>
              Loaded nachos, wings, and dips made for game night, birthdays, and everything in between.
            </p>
            <p className="tagline">Grab a round for the table.</p>
          </div>
        </div>
      </section>

      <section className="section section-dark section-gallery">
        <div className="container gallery-layout">
          <div className="gallery-copy">
            <h2>Make It Your Kind of Night</h2>
            <p>
              Use this template for a single-location spot or a growing restaurant group. Swap photos, 
              adjust colors, and rewrite copy using Acari&apos;s AI to match your brand voice.
            </p>
            <ul className="checklist warm">
              <li>Dedicated space for promos and limited-time offers</li>
              <li>Built-in reservation and call-to-action buttons</li>
              <li>Mobile-first layout that looks great on every device</li>
            </ul>
          </div>
          <div className="gallery-strip">
            <div className="gallery-card gallery-card-1">
              <div className="gallery-label">Crowd-Pleaser Plates</div>
            </div>
            <div className="gallery-card gallery-card-2">
              <div className="gallery-label">Cocktails &amp; Mocktails</div>
            </div>
            <div className="gallery-card gallery-card-3">
              <div className="gallery-label">Cozy Dining Atmosphere</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
