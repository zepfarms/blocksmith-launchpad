import React from 'react'

const Menu = () => {
  return (
    <section className="section container menu-page">
      <div className="section-header">
        <h1>Menu</h1>
        <p>
          Organize your full menu into easy-to-skim sections for hungry guests scrolling on their phones. 
          Use Acari to rewrite dish names and descriptions in seconds.
        </p>
      </div>

      <div className="menu-layout">
        <div className="menu-column">
          <h2>Starters</h2>
          <div className="menu-group">
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Loaded Nachos</h3>
                <span className="menu-price">$12.99</span>
              </div>
              <p>
                House-made tortilla chips stacked with queso, pico, jalapeños, sour cream, and your choice of chicken or beef.
              </p>
            </div>
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Boneless Wings</h3>
                <span className="menu-price">$11.49</span>
              </div>
              <p>
                Crispy, saucy, and shareable. Choose from buffalo, honey BBQ, or garlic parmesan with ranch or blue cheese.
              </p>
            </div>
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Spinach &amp; Artichoke Dip</h3>
                <span className="menu-price">$10.99</span>
              </div>
              <p>
                Creamy, cheesy dip served warm with toasted chips and fresh-cut veggies.
              </p>
            </div>
          </div>

          <h2>Burgers &amp; Sandwiches</h2>
          <div className="menu-group">
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Smokehouse Burger</h3>
                <span className="menu-price">$14.99</span>
              </div>
              <p>
                Angus patty, cheddar, crispy onions, bacon, and smoky BBQ sauce on a toasted brioche bun.
              </p>
            </div>
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Crispy Chicken Sandwich</h3>
                <span className="menu-price">$13.49</span>
              </div>
              <p>
                Buttermilk-fried chicken breast with pickles, slaw, and house sauce.
              </p>
            </div>
          </div>
        </div>

        <div className="menu-column">
          <h2>Fajitas &amp; Mains</h2>
          <div className="menu-group">
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Chicken Fajitas</h3>
                <span className="menu-price">$17.99</span>
              </div>
              <p>
                Sizzling skillet with marinated chicken, peppers, onions, warm tortillas, rice, beans, and all the toppings.
              </p>
            </div>
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Rib Platter</h3>
                <span className="menu-price">$21.99</span>
              </div>
              <p>
                Slow-cooked ribs glazed in house BBQ sauce, served with fries and slaw.
              </p>
            </div>
          </div>

          <h2>Drinks &amp; Desserts</h2>
          <div className="menu-group">
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Signature Margaritas</h3>
                <span className="menu-price">$9.50</span>
              </div>
              <p>
                Classic, frozen, or on the rocks—with seasonal fruit flavors and sugar or salt rims.
              </p>
            </div>
            <div className="menu-item">
              <div className="menu-item-header">
                <h3>Skillet Cookie Sundae</h3>
                <span className="menu-price">$8.99</span>
              </div>
              <p>
                Warm chocolate chip cookie topped with ice cream, chocolate drizzle, and whipped cream.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Menu
