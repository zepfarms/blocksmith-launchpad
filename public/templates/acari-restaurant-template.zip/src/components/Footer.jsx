import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo">
            <span className="logo-mark">GR</span>
            <span className="logo-text">
              <span className="logo-primary">Gather</span>
              <span className="logo-sub">Grill &amp; Bar</span>
            </span>
          </div>
          <p className="footer-text">
            A warm, modern restaurant template for neighborhood grills, family spots, and casual dining chains.
            Swap photos, colors, and copy in minutes with Acari.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Location</h4>
          <p className="footer-text">
            456 Main Street<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Hours</h4>
          <p className="footer-text">
            Sun–Thu: 11:00am – 10:00pm<br />
            Fri–Sat: 11:00am – 12:00am
          </p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Gather Grill &amp; Bar. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
