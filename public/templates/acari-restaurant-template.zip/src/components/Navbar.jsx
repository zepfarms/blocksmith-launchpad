import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="navbar-inner container">
        <Link to="/" className="logo">
          <span className="logo-mark">GR</span>
          <span className="logo-text">
            <span className="logo-primary">Gather</span>
            <span className="logo-sub">Grill &amp; Bar</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/menu" className="nav-link">
            Menu
          </NavLink>
          <NavLink to="/visit" className="nav-link">
            Visit Us
          </NavLink>
        </nav>
        <a href="#reserve" className="nav-cta">
          Reserve a Table
        </a>
      </div>
    </header>
  )
}

export default Navbar
