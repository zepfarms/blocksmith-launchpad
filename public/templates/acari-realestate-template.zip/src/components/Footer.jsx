import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer re-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo re-logo">
            <span className="logo-mark re-logo-mark">HS</span>
            <span className="logo-text">
              <span className="logo-primary">Harbor &amp; Stone</span>
              <span className="logo-sub">Realty Group</span>
            </span>
          </div>
          <p className="footer-text">
            A polished template for solo agents, small teams, and boutique brokerages. Swap colors, photos, 
            and neighborhoods with Acari to match any market.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Office</h4>
          <p className="footer-text">
            220 Market Street, Suite 300<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Navigate</h4>
          <ul className="footer-links">
            <li>
              <Link to="/listings">Featured Listings</Link>
            </li>
            <li>
              <Link to="/contact">Buy, Sell &amp; Contact</Link>
            </li>
            <li>
              <a href="#consult">Schedule a Consult</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Harbor &amp; Stone Realty Group. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
