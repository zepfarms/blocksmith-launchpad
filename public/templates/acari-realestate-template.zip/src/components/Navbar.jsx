import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar re-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo re-logo">
          <span className="logo-mark re-logo-mark">HS</span>
          <span className="logo-text">
            <span className="logo-primary">Harbor &amp; Stone</span>
            <span className="logo-sub">Realty Group</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/listings" className="nav-link">
            Listings
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Buy, Sell &amp; Contact
          </NavLink>
        </nav>
        <a href="#consult" className="nav-cta nav-cta-re">
          Schedule a Consult
        </a>
      </div>
    </header>
  )
}

export default Navbar
