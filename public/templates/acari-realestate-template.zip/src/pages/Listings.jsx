import React from 'react'

const Listings = () => {
  return (
    <section className="section container listings-page listings-page-re">
      <div className="section-header">
        <h1>Featured Listings</h1>
        <p>
          Swap these cards for your active listings, recent sales, or coming-soon properties. Link them out 
          to full detail pages or your MLS home search.
        </p>
      </div>

      <div className="listings-layout-re">
        <div className="listing-grid-re">
          <article className="listing-card-re listing-card-re-1">
            <div className="listing-tag-re listing-tag-re-active">For Sale</div>
            <div className="listing-body-re">
              <h2>Modern Craftsman on Maple Street</h2>
              <p className="listing-meta-re">3 Beds • 2.5 Baths • 2,100 Sq Ft</p>
              <p className="listing-price-re">$625,000</p>
              <p className="listing-copy-re">
                Light-filled living spaces, an open kitchen, and a private backyard built for weekend hangs.
              </p>
              <button className="btn btn-secondary btn-secondary-re">View Details</button>
            </div>
          </article>

          <article className="listing-card-re listing-card-re-2">
            <div className="listing-tag-re listing-tag-re-pending">Pending</div>
            <div className="listing-body-re">
              <h2>Downtown Loft with Skyline Views</h2>
              <p className="listing-meta-re">2 Beds • 2 Baths • 1,350 Sq Ft</p>
              <p className="listing-price-re">$489,000</p>
              <p className="listing-copy-re">
                Exposed brick, tall ceilings, and walkable access to coffee, food, and nightlife.
              </p>
              <button className="btn btn-secondary btn-secondary-re">View Details</button>
            </div>
          </article>

          <article className="listing-card-re listing-card-re-3">
            <div className="listing-tag-re listing-tag-re-sold">Recently Sold</div>
            <div className="listing-body-re">
              <h2>Family Home Near Willow Park</h2>
              <p className="listing-meta-re">4 Beds • 3 Baths • 2,450 Sq Ft</p>
              <p className="listing-price-re">$712,000</p>
              <p className="listing-copy-re">
                Closed with multiple offers—share a quick story here about how you helped your sellers win.
              </p>
              <button className="btn btn-secondary btn-secondary-re">See Case Study</button>
            </div>
          </article>
        </div>

        <aside className="listings-sidebar-re">
          <div className="sidebar-card sidebar-card-re">
            <h3>Search All Homes</h3>
            <p>
              Use this space for a search link, IDX connection, or simple CTA that sends visitors to your 
              full home search experience.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-re">
            <h3>Buyer &amp; Seller Guides</h3>
            <p>
              Link free PDF guides here to capture leads and walk people through what to expect in your market.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-re">
            <h3>Recent Wins</h3>
            <p>
              Add a short list of record-breaking sales, fast closings, or tough deals you navigated.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Listings
