import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-re">
      <div className="section-header">
        <h1>Buy, Sell &amp; Contact</h1>
        <p>
          Help future clients understand how to reach you, what areas you serve, and what happens after they 
          click &quot;submit&quot; on this form.
        </p>
      </div>

      <div className="contact-layout contact-layout-re">
        <div className="contact-card contact-card-re">
          <h2>Tell Me About Your Move</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              Phone
              <input type="tel" placeholder="(555) 555-5555" />
            </label>
            <label>
              Are you looking to buy, sell, or both?
              <textarea
                rows="4"
                placeholder="Share a quick snapshot of your timeline, price range, and ideal neighborhoods."
              />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-re btn-full">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-info contact-info-re">
          <div className="info-block">
            <h3>Service Areas</h3>
            <p>
              City Name, Surrounding Suburbs, Nearby Counties<br />
              Add your core neighborhoods or condo buildings here.
            </p>
          </div>
          <div className="info-block">
            <h3>Office &amp; Contact</h3>
            <p>
              Office: 220 Market Street, Suite 300<br />
              Phone: (555) 555-5555<br />
              Email: hello@harborandstone.com
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              By appointment, with flexible evening and weekend availability.<br />
              Note: Real estate doesn&apos;t always fit into 9–5—make this work for you.
            </p>
          </div>
          <div className="info-block">
            <h3>Map &amp; Parking</h3>
            <p>
              Describe where to park, how to access your office or meeting space, and any building details.
            </p>
            <div className="map-placeholder map-placeholder-re">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
