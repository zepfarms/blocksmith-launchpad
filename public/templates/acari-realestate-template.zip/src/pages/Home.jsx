import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-re">
        <div className="hero-overlay hero-overlay-re" />
        <div className="container hero-content hero-content-re">
          <div>
            <p className="hero-kicker hero-kicker-re">Buying • Selling • Relocating</p>
            <h1 className="hero-title hero-title-re">
              Move with Confidence,
              <span className="hero-highlight hero-highlight-re"> Not Guesswork.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-re">
              Clear guidance, honest pricing, and strategy for every step—whether you&apos;re buying your first 
              home, moving up, or selling from out of state.
            </p>
            <div className="hero-actions">
              <a href="#consult" className="btn btn-primary btn-primary-re">
                Schedule a Consult
              </a>
              <Link to="/listings" className="btn btn-secondary btn-secondary-re">
                View Featured Homes
              </Link>
            </div>
            <div className="hero-badges hero-badges-re">
              <div className="badge">
                <span className="badge-number">Top 1%</span>
                <span className="badge-label">Local Agent Volume</span>
              </div>
              <div className="badge">
                <span className="badge-number">200+</span>
                <span className="badge-label">Homes Closed</span>
              </div>
              <div className="badge">
                <span className="badge-number">5★</span>
                <span className="badge-label">Client Reviews</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-re">
            <div className="hero-card-header">
              <h2>Plan Your Next Move</h2>
              <p>Share a few details and we&apos;ll follow up with a tailored game plan for your goals.</p>
            </div>
            <form className="hero-form" id="consult">
              <label>
                I&apos;m Looking To
                <select defaultValue="Buy a Home">
                  <option>Buy a Home</option>
                  <option>Sell a Home</option>
                  <option>Buy &amp; Sell</option>
                  <option>Relocate</option>
                  <option>Invest</option>
                </select>
              </label>
              <label>
                Name
                <input type="text" placeholder="Full name" />
              </label>
              <label>
                Email
                <input type="email" placeholder="you@example.com" />
              </label>
              <label>
                Ideal Timeline
                <select defaultValue="0–3 Months">
                  <option>0–3 Months</option>
                  <option>3–6 Months</option>
                  <option>6–12 Months</option>
                  <option>Just Researching</option>
                </select>
              </label>
              <button type="submit" className="btn btn-primary btn-primary-re btn-full">
                Request Strategy Call
              </button>
              <p className="hero-form-note">
                No pressure, no spam—just clear next steps based on your situation and local data.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-re">
        <div className="section-header">
          <h2>Real Estate, Explained in Plain English</h2>
          <p>
            Use this layout as a solo agent or team. Swap the copy and photos to match your city, niches, 
            and personality—Acari will handle the heavy lifting.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-re">
            <h3>Guided Buying</h3>
            <p>
              From pre-approval to keys, outline how you help buyers win the right home without overpaying.
            </p>
          </div>
          <div className="feature-card feature-card-re">
            <h3>Strategic Selling</h3>
            <p>
              Explain pricing, prep, and marketing plans that get offers—without endless showings and stress.
            </p>
          </div>
          <div className="feature-card feature-card-re">
            <h3>Local Expertise</h3>
            <p>
              Highlight your neighborhoods, data-backed insights, and what makes your market unique.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-soft-re section-gallery-re">
        <div className="container gallery-layout-re">
          <div className="gallery-copy-re">
            <h2>Show the Homes &amp; the Lifestyle</h2>
            <p>
              Use this band for neighborhood shots, interiors, and client moments. Future buyers should feel 
              what it&apos;s like to actually live here, not just see square footage.
            </p>
            <ul className="checklist checklist-re">
              <li>Swap imagery for your real listings and favorite areas</li>
              <li>Call out schools, parks, commutes, or amenities buyers ask about</li>
              <li>Add short client stories or testimonials near this section</li>
            </ul>
          </div>
          <div className="gallery-strip-re">
            <div className="gallery-card-re gallery-card-re-1">
              <div className="gallery-label-re">Interiors</div>
            </div>
            <div className="gallery-card-re gallery-card-re-2">
              <div className="gallery-label-re">Neighborhoods</div>
            </div>
            <div className="gallery-card-re gallery-card-re-3">
              <div className="gallery-label-re">Happy Closings</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
