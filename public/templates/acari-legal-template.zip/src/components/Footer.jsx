import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer lg-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo logo-legal">
            <span className="logo-mark">HL</span>
            <span className="logo-text">
              <span className="logo-primary">Harbor</span>
              <span className="logo-sub">Law Group</span>
            </span>
          </div>
          <p className="footer-text">
            A modern, trustworthy template for law firms, consultants, agencies, and professional service 
            providers. Swap colors, practice areas, and copy with Acari.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Office</h4>
          <p className="footer-text">
            1000 Harbor Plaza, Suite 400<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Links</h4>
          <ul className="footer-links">
            <li>
              <Link to="/services">Practice Areas</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <a href="#consult">Book a Consultation</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Harbor Law Group. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
