import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar lg-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo logo-legal">
          <span className="logo-mark">HL</span>
          <span className="logo-text">
            <span className="logo-primary">Harbor</span>
            <span className="logo-sub">Law Group</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Practice Areas
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact</NavLink>
        </nav>
        <a href="#consult" className="nav-cta nav-cta-legal">
          Schedule Consultation
        </a>
      </div>
    </header>
  )
}

export default Navbar
