import React from 'react'

const Services = () => {
  return (
    <section className="section container services-page services-page-legal">
      <div className="section-header">
        <h1>Practice Areas</h1>
        <p>
          Customize these sections to match your firm or professional practice. Swap titles and descriptions 
          for any mix of law, finance, consulting, or advisory services.
        </p>
      </div>

      <div className="services-layout services-layout-legal">
        <div className="services-main">
          <h2>Business &amp; Transactions</h2>
          <div className="service-group">
            <div className="service-item service-item-legal">
              <h3>Entity Formation &amp; Governance</h3>
              <p>
                Guidance on choosing the right entity structure, drafting formation documents, and setting up 
                governance that supports long-term growth.
              </p>
              <p className="service-meta">Startups • Small Businesses • Partnerships</p>
            </div>
            <div className="service-item service-item-legal">
              <h3>Contracts &amp; Agreements</h3>
              <p>
                Drafting and reviewing commercial agreements, vendor contracts, NDAs, and partnership 
                arrangements to reduce risk and prevent disputes.
              </p>
              <p className="service-meta">Flat-fee and ongoing support options</p>
            </div>
            <div className="service-item service-item-legal">
              <h3>M&amp;A &amp; Strategic Deals</h3>
              <p>
                Support for buyers and sellers on acquisitions, investments, and other significant 
                transactions.
              </p>
              <p className="service-meta">From initial LOIs to closing</p>
            </div>
          </div>

          <h2>Individual &amp; Family Matters</h2>
          <div className="service-group">
            <div className="service-item service-item-legal">
              <h3>Estate Planning</h3>
              <p>
                Wills, trusts, powers of attorney, and related planning tailored to your goals and family 
                dynamics.
              </p>
            </div>
            <div className="service-item service-item-legal">
              <h3>Real Estate</h3>
              <p>
                Residential and small commercial transactions, lease reviews, and related contract support.
              </p>
            </div>
          </div>
        </div>

        <aside className="services-sidebar services-sidebar-legal">
          <div className="sidebar-card sidebar-card-legal">
            <h3>Who We Serve</h3>
            <p>
              Use this space to describe your ideal clients—founders, families, professionals, or specific 
              industries.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-legal">
            <h3>Engagement Options</h3>
            <p>
              Flat-fee projects, hourly work, or fractional general counsel—outline how clients can work 
              with you.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-legal">
            <h3>Representative Matters</h3>
            <p>
              Add anonymized examples of past matters or projects to demonstrate experience and outcomes.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Services
