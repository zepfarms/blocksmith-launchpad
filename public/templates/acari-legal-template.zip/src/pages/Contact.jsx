import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-legal">
      <div className="section-header">
        <h1>Contact</h1>
        <p>
          Provide clear next steps for potential clients, whether that&apos;s a short intro call, a discovery 
          meeting, or a detailed intake form.
        </p>
      </div>

      <div className="contact-layout contact-layout-legal">
        <div className="contact-card contact-card-legal">
          <h2>Get in Touch</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              Phone
              <input type="tel" placeholder="(555) 555-5555" />
            </label>
            <label>
              How can we help?
              <textarea rows="4" placeholder="Briefly describe your situation or questions." />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-legal btn-full">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-info contact-info-legal">
          <div className="info-block">
            <h3>Office</h3>
            <p>
              1000 Harbor Plaza, Suite 400<br />
              Your City, ST 12345
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Mon–Fri: 8:30am – 5:30pm<br />
              Evenings by appointment
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Email: hello@yourfirm.com
            </p>
          </div>
          <div className="info-block">
            <h3>Map &amp; Parking</h3>
            <p>
              Replace this placeholder with a map embed and simple parking instructions for your office.
            </p>
            <div className="map-placeholder">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
