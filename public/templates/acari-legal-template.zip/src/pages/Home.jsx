import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-legal">
        <div className="hero-overlay hero-overlay-legal" />
        <div className="container hero-content hero-content-legal">
          <div>
            <p className="hero-kicker hero-kicker-legal">Business • Litigation • Personal Counsel</p>
            <h1 className="hero-title hero-title-legal">
              Clarity, Strategy,
              <span className="hero-highlight hero-highlight-legal"> and Trusted Counsel.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-legal">
              We help clients navigate complex legal decisions with practical guidance, clear communication, 
              and a calm, results-focused approach.
            </p>
            <div className="hero-actions">
              <a href="#consult" className="btn btn-primary btn-primary-legal">
                Schedule Consultation
              </a>
              <Link to="/services" className="btn btn-secondary btn-secondary-legal">
                View Practice Areas
              </Link>
            </div>
            <div className="hero-badges hero-badges-legal">
              <div className="badge">
                <span className="badge-number">15+ yrs</span>
                <span className="badge-label">Combined Experience</span>
              </div>
              <div className="badge">
                <span className="badge-number">300+</span>
                <span className="badge-label">Clients Advised</span>
              </div>
              <div className="badge">
                <span className="badge-number">5.0★</span>
                <span className="badge-label">Client Reviews</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-legal">
            <div className="hero-card-header">
              <h2>Request a Consultation</h2>
              <p>Share a few details and our team will follow up within one business day.</p>
            </div>
            <form className="hero-form" id="consult">
              <label>
                Area of Need
                <select defaultValue="Business Law">
                  <option>Business Law</option>
                  <option>Contracts &amp; Agreements</option>
                  <option>Real Estate</option>
                  <option>Estate Planning</option>
                  <option>Litigation / Dispute</option>
                  <option>Other</option>
                </select>
              </label>
              <label>
                Name
                <input type="text" placeholder="Alex Client" />
              </label>
              <label>
                Email
                <input type="email" placeholder="you@example.com" />
              </label>
              <label>
                Phone
                <input type="tel" placeholder="(555) 555-5555" />
              </label>
              <button type="submit" className="btn btn-primary btn-primary-legal btn-full">
                Submit Request
              </button>
              <p className="hero-form-note">
                Please do not share confidential details here. A brief overview is enough to determine fit.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-legal">
        <div className="section-header">
          <h2>Built for Modern Professional Services</h2>
          <p>
            Use this layout for law firms, accountants, consultants, agencies, or any practice that relies on 
            trust, reputation, and ongoing client relationships.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-legal">
            <h3>Clear Positioning</h3>
            <p>
              Explain who you serve and what you do in plain language that clients actually understand.
            </p>
          </div>
          <div className="feature-card feature-card-legal">
            <h3>Service Overview</h3>
            <p>
              Highlight your core offerings and typical engagements, from one-time consults to ongoing counsel.
            </p>
          </div>
          <div className="feature-card feature-card-legal">
            <h3>Trust Signals</h3>
            <p>
              Add testimonials, case highlights, logos, and credentials to build confidence quickly.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-dark section-legal">
        <div className="container split split-legal">
          <div>
            <h2>A Calmer Way to Handle Complex Matters</h2>
            <p>
              Clients don&apos;t just need legal answers—they need a partner who can listen, explain their options, 
              and chart a plan that fits their goals and risk tolerance.
            </p>
            <ul className="checklist checklist-legal">
              <li>Straightforward communication without dense legal jargon</li>
              <li>Thoughtful strategy tailored to each client&apos;s situation</li>
              <li>Flexible engagement models: project-based or ongoing counsel</li>
            </ul>
          </div>
          <div className="highlight-card highlight-card-legal">
            <p className="highlight-tag">Template Highlight</p>
            <h3>Designed for Credibility &amp; Conversion</h3>
            <p>
              Every section is structured so Acari&apos;s AI can rewrite it for different practice areas or 
              professions while preserving a premium, trustworthy feel.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
