import React from 'react'

const Portfolio = () => {
  return (
    <section className="section container portfolio-page portfolio-page-cr">
      <div className="section-header">
        <h1>Portfolio</h1>
        <p>
          Mix project highlights, curated galleries, and simple case studies. You can adapt this grid for 
          branding, product, weddings, or any creative niche.
        </p>
      </div>

      <div className="portfolio-layout-cr">
        <div className="portfolio-grid-cr">
          <article className="portfolio-card-cr portfolio-card-cr-1">
            <div className="portfolio-tag-cr">Brand &amp; Web</div>
            <div className="portfolio-body-cr">
              <h2>Northline Coffee Co.</h2>
              <p>
                Visual identity, packaging, and launch site for a neighborhood coffee brand expanding online.
              </p>
              <button className="btn btn-secondary btn-secondary-cr">View Project</button>
            </div>
          </article>

          <article className="portfolio-card-cr portfolio-card-cr-2">
            <div className="portfolio-tag-cr">Editorial</div>
            <div className="portfolio-body-cr">
              <h2>Studio Light Series</h2>
              <p>
                A portrait series exploring color, shape, and shadow for a print and digital campaign.
              </p>
              <button className="btn btn-secondary btn-secondary-cr">View Project</button>
            </div>
          </article>

          <article className="portfolio-card-cr portfolio-card-cr-3">
            <div className="portfolio-tag-cr">Portraits</div>
            <div className="portfolio-body-cr">
              <h2>Founders in Motion</h2>
              <p>
                Lifestyle sessions for startup teams, shot in real workspaces and city streets.
              </p>
              <button className="btn btn-secondary btn-secondary-cr">View Project</button>
            </div>
          </article>

          <article className="portfolio-card-cr portfolio-card-cr-4">
            <div className="portfolio-tag-cr">Weddings / Events</div>
            <div className="portfolio-body-cr">
              <h2>Amelia &amp; Rian</h2>
              <p>
                Intimate city wedding coverage with a focus on quiet, between-the-moment details.
              </p>
              <button className="btn btn-secondary btn-secondary-cr">View Project</button>
            </div>
          </article>
        </div>

        <aside className="portfolio-sidebar-cr">
          <div className="sidebar-card sidebar-card-cr">
            <h3>How to Use This Page</h3>
            <p>
              Swap titles, descriptions, and background images for your real projects. Link buttons to more 
              detailed case studies, galleries, or external platforms.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-cr">
            <h3>Selected Clients</h3>
            <p>
              Use this to list a few recognizable names, publications, or collaborations that build trust.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-cr">
            <h3>Approach &amp; Style</h3>
            <p>
              Share a few sentences about how you work, what you value, and what clients can expect on set.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Portfolio
