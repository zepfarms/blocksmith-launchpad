import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-cr">
        <div className="hero-overlay hero-overlay-cr" />
        <div className="container hero-content hero-content-cr">
          <div>
            <p className="hero-kicker hero-kicker-cr">Branding • Photography • Visual Design</p>
            <h1 className="hero-title hero-title-cr">
              Images &amp; Identities
              <span className="hero-highlight hero-highlight-cr"> That Feel Like You.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-cr">
              Thoughtful visuals for brands, founders, and couples who care about the details—from polished 
              identities to honest, in-between moments.
            </p>
            <div className="hero-actions">
              <a href="#inquiry" className="btn btn-primary btn-primary-cr">
                Book a Project
              </a>
              <Link to="/portfolio" className="btn btn-secondary btn-secondary-cr">
                View Portfolio
              </Link>
            </div>
            <div className="hero-badges hero-badges-cr">
              <div className="badge">
                <span className="badge-number">10+ Years</span>
                <span className="badge-label">Behind the Lens</span>
              </div>
              <div className="badge">
                <span className="badge-number">Brands &amp; Weddings</span>
                <span className="badge-label">Multi-Discipline Studio</span>
              </div>
              <div className="badge">
                <span className="badge-number">Global</span>
                <span className="badge-label">Remote-Friendly</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-cr">
            <div className="hero-card-header">
              <h2>Project Inquiry</h2>
              <p>Share a few details so we can follow up with scope, timeline, and next steps.</p>
            </div>
            <form className="hero-form" id="inquiry">
              <label>
                Name
                <input type="text" placeholder="Full name" />
              </label>
              <label>
                Email
                <input type="email" placeholder="you@example.com" />
              </label>
              <label>
                Project Type
                <select defaultValue="Brand Identity">
                  <option>Brand Identity</option>
                  <option>Website / Digital Design</option>
                  <option>Portrait Session</option>
                  <option>Wedding / Event Photography</option>
                  <option>Product / Editorial Photography</option>
                  <option>Other Creative Project</option>
                </select>
              </label>
              <label>
                Ideal Timeline
                <select defaultValue="0–3 Months">
                  <option>0–3 Months</option>
                  <option>3–6 Months</option>
                  <option>6+ Months</option>
                  <option>Just Gathering Info</option>
                </select>
              </label>
              <button type="submit" className="btn btn-primary btn-primary-cr btn-full">
                Submit Inquiry
              </button>
              <p className="hero-form-note">
                You can customize this text to explain your process, response times, or minimum project size.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-cr">
        <div className="section-header">
          <h2>Built for Visual Storytellers</h2>
          <p>
            Use this layout for individual designers, photographers, or full creative studios. Acari can 
            rewrite each block to match your tone, niche, and services.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-cr">
            <h3>Brand &amp; Web Design</h3>
            <p>
              Highlight strategy-driven branding, typography, and digital experiences for founders and teams.
            </p>
          </div>
          <div className="feature-card feature-card-cr">
            <h3>Portrait &amp; Lifestyle</h3>
            <p>
              Describe sessions for entrepreneurs, artists, and families in spaces that feel natural to them.
            </p>
          </div>
          <div className="feature-card feature-card-cr">
            <h3>Editorial &amp; Campaigns</h3>
            <p>
              Outline production, locations, and deliverables for bigger shoots, launches, or collaborations.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-soft-cr section-gallery-cr">
        <div className="container gallery-layout-cr">
          <div className="gallery-copy-cr">
            <h2>Let the Work Lead</h2>
            <p>
              Swap these hero images with your favorite projects. Keep the layout clean so clients can focus 
              on the work, not the website.
            </p>
            <ul className="checklist checklist-cr">
              <li>Use this band to feature 3 key projects or categories</li>
              <li>Pair visuals with short captions about role and results</li>
              <li>Link each tile to a full case study or gallery</li>
            </ul>
          </div>
          <div className="gallery-strip-cr">
            <div className="gallery-card-cr gallery-card-cr-1">
              <div className="gallery-label-cr">Brand &amp; Web</div>
            </div>
            <div className="gallery-card-cr gallery-card-cr-2">
              <div className="gallery-label-cr">Editorial</div>
            </div>
            <div className="gallery-card-cr gallery-card-cr-3">
              <div className="gallery-label-cr">Portraits</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
