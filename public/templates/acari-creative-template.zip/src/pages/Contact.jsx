import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-cr">
      <div className="section-header">
        <h1>Services &amp; Contact</h1>
        <p>
          Outline your core offerings, typical timelines, and how to start a project. Keep it clear so clients 
          know what working together actually looks like.
        </p>
      </div>

      <div className="contact-layout contact-layout-cr">
        <div className="contact-card contact-card-cr">
          <h2>Services</h2>
          <div className="service-group">
            <div className="service-item service-item-cr">
              <h3>Brand &amp; Web</h3>
              <p>
                Strategy, identity, and website design packages for new brands or rebrands.
              </p>
            </div>
            <div className="service-item service-item-cr">
              <h3>Photography</h3>
              <p>
                Portrait, lifestyle, editorial, and product photography with on-location or studio options.
              </p>
            </div>
            <div className="service-item service-item-cr">
              <h3>Retainers &amp; Ongoing Support</h3>
              <p>
                Monthly creative support for content, campaigns, and evolving visual needs.
              </p>
            </div>
          </div>
        </div>

        <div className="contact-card contact-card-cr">
          <h2>Get in Touch</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              Tell me a bit about your project
              <textarea
                rows="4"
                placeholder="Share what you’re hoping to create, your timeline, and any links you’d like to include."
              />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-cr btn-full">
              Submit
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}

export default Contact
