import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer cr-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo cr-logo">
            <span className="logo-mark cr-logo-mark">LO</span>
            <span className="logo-text">
              <span className="logo-primary">Lumen</span>
              <span className="logo-sub">Studio</span>
            </span>
          </div>
          <p className="footer-text">
            A flexible template for designers, photographers, and creative studios. Swap imagery, colors, 
            and copy with Acari to fit any niche—from branding to weddings.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Studio</h4>
          <p className="footer-text">
            41 Laurel Street<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Navigate</h4>
          <ul className="footer-links">
            <li>
              <Link to="/portfolio">Portfolio</Link>
            </li>
            <li>
              <Link to="/contact">Services &amp; Contact</Link>
            </li>
            <li>
              <a href="#inquiry">Book a Project</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Lumen Studio. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
