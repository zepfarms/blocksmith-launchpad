import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar cr-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo cr-logo">
          <span className="logo-mark cr-logo-mark">LO</span>
          <span className="logo-text">
            <span className="logo-primary">Lumen</span>
            <span className="logo-sub">Studio</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/portfolio" className="nav-link">
            Portfolio
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Services &amp; Contact
          </NavLink>
        </nav>
        <a href="#inquiry" className="nav-cta nav-cta-cr">
          Book a Project
        </a>
      </div>
    </header>
  )
}

export default Navbar
