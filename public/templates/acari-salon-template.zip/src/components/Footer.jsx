import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer salon-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo salon-logo">
            <span className="logo-mark salon-logo-mark">LS</span>
            <span className="logo-text">
              <span className="logo-primary">Lumen</span>
              <span className="logo-sub">Salon &amp; Spa</span>
            </span>
          </div>
          <p className="footer-text">
            A calm, modern template for salons, spas, lash studios, med spas, and wellness brands. 
            Swap imagery, colors, and services in a few prompts with Acari.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Location</h4>
          <p className="footer-text">
            220 Rosewood Avenue<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Explore</h4>
          <ul className="footer-links">
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/contact">Visit &amp; Contact</Link>
            </li>
            <li>
              <a href="#book">Book Now</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Lumen Salon &amp; Spa. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
