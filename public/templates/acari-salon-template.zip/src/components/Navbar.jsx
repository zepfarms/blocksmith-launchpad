import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar salon-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo salon-logo">
          <span className="logo-mark salon-logo-mark">LS</span>
          <span className="logo-text">
            <span className="logo-primary">Lumen</span>
            <span className="logo-sub">Salon &amp; Spa</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Visit &amp; Contact
          </NavLink>
        </nav>
        <a href="#book" className="nav-cta nav-cta-salon">
          Book an Appointment
        </a>
      </div>
    </header>
  )
}

export default Navbar
