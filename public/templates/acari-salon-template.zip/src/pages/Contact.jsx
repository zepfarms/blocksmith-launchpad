import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-salon">
      <div className="section-header">
        <h1>Visit &amp; Contact</h1>
        <p>
          Make it easy for guests to find you, see when you&apos;re open, and reach out with quick questions 
          about services or availability.
        </p>
      </div>

      <div className="contact-layout contact-layout-salon">
        <div className="contact-card contact-card-salon">
          <h2>Send a Note</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              Phone
              <input type="tel" placeholder="(555) 555-5555" />
            </label>
            <label>
              How can we help?
              <textarea rows="4" placeholder="Ask about availability, services, or anything else." />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-salon btn-full">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-info contact-info-salon">
          <div className="info-block">
            <h3>Location</h3>
            <p>
              220 Rosewood Avenue<br />
              Your City, ST 12345
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Mon–Fri: 9:00am – 7:00pm<br />
              Sat: 9:00am – 5:00pm<br />
              Sun: Closed or limited hours
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Email: hello@yoursalon.com<br />
              Social: @yoursalonhandle
            </p>
          </div>
          <div className="info-block">
            <h3>Parking &amp; Arrival</h3>
            <p>
              Use this space for parking details, how to find your entrance, and any arrival notes for new guests.
            </p>
            <div className="map-placeholder map-placeholder-salon">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
