import React from 'react'

const Services = () => {
  return (
    <section className="section container services-page services-page-salon">
      <div className="section-header">
        <h1>Services</h1>
        <p>
          Customize this page with your salon or spa&apos;s real menu. Organize services into clear sections 
          so guests can quickly find what they need.
        </p>
      </div>

      <div className="services-layout services-layout-salon">
        <div className="services-main">
          <h2>Hair</h2>
          <div className="service-group">
            <div className="service-item service-item-salon">
              <h3>Haircut &amp; Style</h3>
              <p>
                Tailored cuts with a relaxing wash, scalp massage, and blow-dry finish.
              </p>
              <p className="service-meta">Short, medium, and long hair pricing</p>
            </div>
            <div className="service-item service-item-salon">
              <h3>Color &amp; Highlights</h3>
              <p>
                Dimensional color, highlights, balayage, and glossing services for soft, blended results.
              </p>
              <p className="service-meta">Consultations available for big changes</p>
            </div>
            <div className="service-item service-item-salon">
              <h3>Blowouts &amp; Styling</h3>
              <p>
                Smooth, bouncy, or beachy styling for events, nights out, or weekly maintenance.
              </p>
            </div>
          </div>

          <h2>Spa &amp; Skin</h2>
          <div className="service-group">
            <div className="service-item service-item-salon">
              <h3>Custom Facials</h3>
              <p>
                Treatments tailored to hydration, clarity, or calm—designed after a brief skin consultation.
              </p>
            </div>
            <div className="service-item service-item-salon">
              <h3>Massage</h3>
              <p>
                Relaxation, deep tissue, or targeted sessions to release tension and reset.
              </p>
            </div>
          </div>

          <h2>Finishing Touches</h2>
          <div className="service-group">
            <div className="service-item service-item-salon">
              <h3>Manicures &amp; Pedicures</h3>
              <p>
                Classic, gel, and spa treatments to keep hands and feet soft and polished.
              </p>
            </div>
            <div className="service-item service-item-salon">
              <h3>Lashes &amp; Brows</h3>
              <p>
                Tints, lifts, and shaping for a low-effort, put-together look.
              </p>
            </div>
          </div>
        </div>

        <aside className="services-sidebar services-sidebar-salon">
          <div className="sidebar-card sidebar-card-salon">
            <h3>Memberships &amp; Packages</h3>
            <p>
              Use this area to highlight monthly blowout clubs, facial memberships, or bridal packages.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-salon">
            <h3>Booking &amp; Policies</h3>
            <p>
              Add your cancellation policy, deposit info, and how guests can modify appointments.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-salon">
            <h3>Featured Products</h3>
            <p>
              Showcase retail lines you carry in-salon, such as haircare, skincare, or candles.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Services
