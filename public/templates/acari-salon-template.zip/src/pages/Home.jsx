import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-salon">
        <div className="hero-overlay hero-overlay-salon" />
        <div className="container hero-content hero-content-salon">
          <div>
            <p className="hero-kicker hero-kicker-salon">Hair • Skin • Relaxation</p>
            <h1 className="hero-title hero-title-salon">
              Light-Filled Beauty,
              <span className="hero-highlight hero-highlight-salon"> Effortless Calm.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-salon">
              From fresh cuts and color to facials and full spa days, Lumen is your place to pause, reset, 
              and walk out glowing.
            </p>
            <div className="hero-actions">
              <a href="#book" className="btn btn-primary btn-primary-salon">
                Book an Appointment
              </a>
              <Link to="/services" className="btn btn-secondary btn-secondary-salon">
                View Services
              </Link>
            </div>
            <div className="hero-badges hero-badges-salon">
              <div className="badge">
                <span className="badge-number">4.9★</span>
                <span className="badge-label">Guest Rating</span>
              </div>
              <div className="badge">
                <span className="badge-number">7 Days</span>
                <span className="badge-label">Open Every Week</span>
              </div>
              <div className="badge">
                <span className="badge-number">Since 2015</span>
                <span className="badge-label">Locally Owned</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-salon">
            <div className="hero-card-header">
              <h2>Quick Booking Request</h2>
              <p>Tell us what you&apos;re looking for and when. We&apos;ll confirm your visit shortly.</p>
            </div>
            <form className="hero-form" id="book">
              <label>
                Service Type
                <select defaultValue="Haircut &amp; Style">
                  <option>Haircut &amp; Style</option>
                  <option>Color &amp; Highlights</option>
                  <option>Facial / Skincare</option>
                  <option>Massage</option>
                  <option>Nails / Manicure</option>
                  <option>Lashes / Brows</option>
                  <option>Other</option>
                </select>
              </label>
              <label>
                Name
                <input type="text" placeholder="Guest name" />
              </label>
              <label>
                Phone
                <input type="tel" placeholder="(555) 555-5555" />
              </label>
              <label>
                Ideal Date
                <input type="date" />
              </label>
              <button type="submit" className="btn btn-primary btn-primary-salon btn-full">
                Request Appointment
              </button>
              <p className="hero-form-note">
                We&apos;ll text or email with available times and a final confirmation.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-salon">
        <div className="section-header">
          <h2>Your Everyday &amp; Special-Occasion Space</h2>
          <p>
            Use this template for hair salons, day spas, med spas, nail studios, or multi-location 
            beauty brands. Acari can rewrite every block in your voice.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-salon">
            <h3>Signature Hair</h3>
            <p>
              Precision cuts, lived-in color, and styling that fits real life—not just photoshoots.
            </p>
          </div>
          <div className="feature-card feature-card-salon">
            <h3>Spa &amp; Skin</h3>
            <p>
              Facials, peels, and targeted treatments to support healthy, glowing skin year-round.
            </p>
          </div>
          <div className="feature-card feature-card-salon">
            <h3>Finishing Touches</h3>
            <p>
              Nails, brows, lashes, and makeup for events, weddings, or just because.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-soft section-gallery-salon">
        <div className="container gallery-layout-salon">
          <div className="gallery-copy-salon">
            <h2>A Calm, Light-Filled Experience</h2>
            <p>
              Show off your space, team, and work with full-width imagery and gallery cards. Swap photos 
              with your own in minutes.
            </p>
            <ul className="checklist checklist-salon">
              <li>Dedicated promo space for packages and memberships</li>
              <li>Designed to look beautiful on mobile and desktop</li>
              <li>Easy-to-skim services with clear calls to book</li>
            </ul>
          </div>
          <div className="gallery-strip-salon">
            <div className="gallery-card-salon gallery-card-salon-1">
              <div className="gallery-label-salon">Soft, Natural Light</div>
            </div>
            <div className="gallery-card-salon gallery-card-salon-2">
              <div className="gallery-label-salon">Hair &amp; Color</div>
            </div>
            <div className="gallery-card-salon gallery-card-salon-3">
              <div className="gallery-label-salon">Spa Moments</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
