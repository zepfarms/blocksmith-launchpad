import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar med-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo med-logo">
          <span className="logo-mark med-logo-mark">HC</span>
          <span className="logo-text">
            <span className="logo-primary">Harbor</span>
            <span className="logo-sub">Care Clinic</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Patients &amp; Contact
          </NavLink>
        </nav>
        <a href="#appointment" className="nav-cta nav-cta-med">
          Book Appointment
        </a>
      </div>
    </header>
  )
}

export default Navbar
