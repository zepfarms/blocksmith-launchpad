import React from 'react'

const Services = () => {
  return (
    <section className="section container services-page services-page-med">
      <div className="section-header">
        <h1>Services</h1>
        <p>
          Customize this page with your clinic&apos;s real services, age ranges, and specialties. Group 
          offerings into sections that are easy for patients to skim.
        </p>
      </div>

      <div className="services-layout services-layout-med">
        <div className="services-main">
          <h2>Primary &amp; Preventive Care</h2>
          <div className="service-group">
            <div className="service-item service-item-med">
              <h3>Annual Wellness Visits</h3>
              <p>
                Routine physicals, preventive screenings, and long-term health planning for adults and children.
              </p>
              <p className="service-meta">Ideal once per year, or as recommended</p>
            </div>
            <div className="service-item service-item-med">
              <h3>Chronic Condition Management</h3>
              <p>
                Ongoing care plans for conditions like diabetes, high blood pressure, asthma, and more.
              </p>
            </div>
            <div className="service-item service-item-med">
              <h3>Vaccines &amp; Immunizations</h3>
              <p>
                Childhood and adult vaccine schedules, seasonal flu shots, and travel-related immunizations.
              </p>
            </div>
          </div>

          <h2>Sick Visits &amp; Same-Day Care</h2>
          <div className="service-group">
            <div className="service-item service-item-med">
              <h3>Acute Illness</h3>
              <p>
                Same-day scheduling for fevers, colds, sore throats, infections, and other new symptoms.
              </p>
            </div>
            <div className="service-item service-item-med">
              <h3>Minor Injuries</h3>
              <p>
                Strains, sprains, cuts, and other non-emergency injuries evaluated and treated.
              </p>
            </div>
          </div>

          <h2>Additional Services</h2>
          <div className="service-group">
            <div className="service-item service-item-med">
              <h3>Onsite Labs</h3>
              <p>
                Basic bloodwork and testing performed in-clinic for faster results and follow-up.
              </p>
            </div>
            <div className="service-item service-item-med">
              <h3>Telehealth Visits</h3>
              <p>
                Virtual visits for select concerns, follow-ups, or medication check-ins when appropriate.
              </p>
            </div>
          </div>
        </div>

        <aside className="services-sidebar services-sidebar-med">
          <div className="sidebar-card sidebar-card-med">
            <h3>Who We See</h3>
            <p>
              Use this space to clarify age ranges, new patient availability, and any specialties your 
              clinicians focus on.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-med">
            <h3>Insurance &amp; Billing</h3>
            <p>
              List major insurance plans, self-pay options, and any payment plans or discounts you offer.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-med">
            <h3>After-Hours Care</h3>
            <p>
              Outline nurse lines, on-call providers, or partner urgent care locations for evenings and weekends.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Services
