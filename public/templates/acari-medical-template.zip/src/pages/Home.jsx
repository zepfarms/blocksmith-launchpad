import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-med">
        <div className="hero-overlay hero-overlay-med" />
        <div className="container hero-content hero-content-med">
          <div>
            <p className="hero-kicker hero-kicker-med">Primary Care • Pediatrics • Family Medicine</p>
            <h1 className="hero-title hero-title-med">
              Everyday Care,
              <span className="hero-highlight hero-highlight-med"> Centered Around You.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-med">
              Same familiar faces. Clear guidance. A clinic designed to make checkups, sick visits, and long-term 
              care feel a little less stressful.
            </p>
            <div className="hero-actions">
              <a href="#appointment" className="btn btn-primary btn-primary-med">
                Book Appointment
              </a>
              <Link to="/services" className="btn btn-secondary btn-secondary-med">
                View Services
              </Link>
            </div>
            <div className="hero-badges hero-badges-med">
              <div className="badge">
                <span className="badge-number">New Patients</span>
                <span className="badge-label">Now Welcome</span>
              </div>
              <div className="badge">
                <span className="badge-number">4.9★</span>
                <span className="badge-label">Patient Reviews</span>
              </div>
              <div className="badge">
                <span className="badge-number">Same-Day</span>
                <span className="badge-label">Appointments Available</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-med">
            <div className="hero-card-header">
              <h2>Request an Appointment</h2>
              <p>Share a few details and our front desk team will follow up to confirm your visit.</p>
            </div>
            <form className="hero-form" id="appointment">
              <label>
                Visit Type
                <select defaultValue="New Patient">
                  <option>New Patient</option>
                  <option>Existing Patient</option>
                  <option>Annual / Physical</option>
                  <option>Sick Visit</option>
                  <option>Follow-Up</option>
                  <option>Other</option>
                </select>
              </label>
              <label>
                Patient Name
                <input type="text" placeholder="Full name" />
              </label>
              <label>
                Phone
                <input type="tel" placeholder="(555) 555-5555" />
              </label>
              <label>
                Preferred Date
                <input type="date" />
              </label>
              <button type="submit" className="btn btn-primary btn-primary-med btn-full">
                Submit Request
              </button>
              <p className="hero-form-note">
                For urgent concerns, please call the office directly or dial emergency services.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-med">
        <div className="section-header">
          <h2>Designed for Real Families &amp; Busy Schedules</h2>
          <p>
            Use this template for family medicine, pediatrics, internal medicine, dental, eye care, or most 
            outpatient clinics. Acari can tailor every word to your practice.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-med">
            <h3>Primary &amp; Preventive Care</h3>
            <p>
              Annual exams, wellness visits, and screenings that keep long-term health on track.
            </p>
          </div>
          <div className="feature-card feature-card-med">
            <h3>Sick Visits &amp; Follow-Ups</h3>
            <p>
              Same-day and next-day appointments for fevers, colds, injuries, and new concerns.
            </p>
          </div>
          <div className="feature-card feature-card-med">
            <h3>Care Coordination</h3>
            <p>
              Referrals, prescriptions, labs, and specialist coordination all in one place.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-soft-med section-gallery-med">
        <div className="container gallery-layout-med">
          <div className="gallery-copy-med">
            <h2>Bright, Calm, and Easy to Navigate</h2>
            <p>
              Show your waiting room, exam rooms, and clinical team so new patients know what to expect. 
              Swap these photos with real images from your practice.
            </p>
            <ul className="checklist checklist-med">
              <li>Highlight accessibility, parking, and family-friendly amenities</li>
              <li>Add simple copy about your care philosophy and values</li>
              <li>Use callouts for evening hours, virtual visits, and on-call options</li>
            </ul>
          </div>
          <div className="gallery-strip-med">
            <div className="gallery-card-med gallery-card-med-1">
              <div className="gallery-label-med">Welcome Area</div>
            </div>
            <div className="gallery-card-med gallery-card-med-2">
              <div className="gallery-label-med">Exam Rooms</div>
            </div>
            <div className="gallery-card-med gallery-card-med-3">
              <div className="gallery-label-med">Care Team</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
