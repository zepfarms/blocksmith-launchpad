import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-med">
      <div className="section-header">
        <h1>Patients &amp; Contact</h1>
        <p>
          Help patients quickly find your address, hours, forms, and the best way to get in touch for 
          appointments or questions.
        </p>
      </div>

      <div className="contact-layout contact-layout-med">
        <div className="contact-card contact-card-med">
          <h2>Send a Message</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              Phone
              <input type="tel" placeholder="(555) 555-5555" />
            </label>
            <label>
              How can we help?
              <textarea rows="4" placeholder="Ask about scheduling, services, or other non-urgent questions." />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-med btn-full">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-info contact-info-med">
          <div className="info-block">
            <h3>Location</h3>
            <p>
              410 Wellness Way<br />
              Your City, ST 12345
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Mon–Fri: 8:00am – 5:00pm<br />
              Sat: Limited hours or closed<br />
              Sun: Closed
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Fax: (555) 555-0000<br />
              Patient Portal: Add your link here
            </p>
          </div>
          <div className="info-block">
            <h3>Parking &amp; Arrival</h3>
            <p>
              Use this section for parking details, which entrance to use, elevator access, and any 
              check-in instructions.
            </p>
            <div className="map-placeholder map-placeholder-med">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
