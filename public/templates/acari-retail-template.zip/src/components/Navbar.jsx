import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar retail-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo retail-logo">
          <span className="logo-mark retail-logo-mark">NA</span>
          <span className="logo-text">
            <span className="logo-primary">North</span>
            <span className="logo-sub">Atelier</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/collections" className="nav-link">
            Collections
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Visit &amp; Contact
          </NavLink>
        </nav>
        <a href="#shop" className="nav-cta nav-cta-retail">
          Shop New Arrivals
        </a>
      </div>
    </header>
  )
}

export default Navbar
