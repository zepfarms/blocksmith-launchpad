import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer retail-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo retail-logo">
            <span className="logo-mark retail-logo-mark">NA</span>
            <span className="logo-text">
              <span className="logo-primary">North</span>
              <span className="logo-sub">Atelier</span>
            </span>
          </div>
          <p className="footer-text">
            A flexible retail template for clothing boutiques, lifestyle shops, home goods, and local brands. 
            Swap photos, colors, and copy for any in-store or online shop.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Store</h4>
          <p className="footer-text">
            145 Market Lane<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Explore</h4>
          <ul className="footer-links">
            <li>
              <Link to="/collections">Collections</Link>
            </li>
            <li>
              <Link to="/contact">Visit &amp; Contact</Link>
            </li>
            <li>
              <a href="#shop">Shop New Arrivals</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} North Atelier. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
