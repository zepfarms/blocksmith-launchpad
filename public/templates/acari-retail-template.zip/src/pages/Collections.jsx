import React from 'react'

const Collections = () => {
  return (
    <section className="section container collections-page collections-page-retail">
      <div className="section-header">
        <h1>Collections</h1>
        <p>
          Use this page as a simple, high-level overview of your main categories. Link these sections to 
          product pages, lookbooks, or external shops as needed.
        </p>
      </div>

      <div className="collections-layout-retail">
        <div className="collection-grid-retail">
          <div className="collection-card-retail collection-card-retail-1">
            <div className="collection-overlay-retail" />
            <div className="collection-content-retail">
              <h2>Everyday Essentials</h2>
              <p>Tees, tanks, and relaxed pieces that form the base of your wardrobe.</p>
              <button className="btn btn-secondary btn-secondary-retail">View Essentials</button>
            </div>
          </div>
          <div className="collection-card-retail collection-card-retail-2">
            <div className="collection-overlay-retail" />
            <div className="collection-content-retail">
              <h2>Denim &amp; Bottoms</h2>
              <p>Denim, trousers, and skirts—tailored, relaxed, and everything in-between.</p>
              <button className="btn btn-secondary btn-secondary-retail">View Denim</button>
            </div>
          </div>
          <div className="collection-card-retail collection-card-retail-3">
            <div className="collection-overlay-retail" />
            <div className="collection-content-retail">
              <h2>Layers &amp; Outerwear</h2>
              <p>Knits, jackets, and coats designed for layering through the seasons.</p>
              <button className="btn btn-secondary btn-secondary-retail">View Outerwear</button>
            </div>
          </div>
          <div className="collection-card-retail collection-card-retail-4">
            <div className="collection-overlay-retail" />
            <div className="collection-content-retail">
              <h2>Accessories</h2>
              <p>Bags, hats, jewelry, and small pieces that finish the look.</p>
              <button className="btn btn-secondary btn-secondary-retail">View Accessories</button>
            </div>
          </div>
        </div>

        <aside className="collections-sidebar-retail">
          <div className="sidebar-card sidebar-card-retail">
            <h3>How to Use This Page</h3>
            <p>
              Swap titles, descriptions, and background images for your real categories. Link the buttons to 
              collection pages, a Shopify store, or another platform.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-retail">
            <h3>Featured Drops</h3>
            <p>
              Use this space to highlight seasonal edits, collaborations, or limited-run capsules.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-retail">
            <h3>Gifting &amp; Events</h3>
            <p>
              Add information about gift cards, private shopping appointments, or after-hours events.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Collections
