import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-retail">
        <div className="hero-overlay hero-overlay-retail" />
        <div className="container hero-content hero-content-retail">
          <div>
            <p className="hero-kicker hero-kicker-retail">Clothing • Lifestyle • Everyday Essentials</p>
            <h1 className="hero-title hero-title-retail">
              Effortless Pieces,
              <span className="hero-highlight hero-highlight-retail"> Made to Be Worn.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-retail">
              Curated staples, soft layers, and accessories you actually reach for—designed to move from 
              weekdays to weekends without overthinking it.
            </p>
            <div className="hero-actions">
              <a href="#shop" className="btn btn-primary btn-primary-retail">
                Shop New Arrivals
              </a>
              <Link to="/collections" className="btn btn-secondary btn-secondary-retail">
                Browse Collections
              </Link>
            </div>
            <div className="hero-badges hero-badges-retail">
              <div className="badge">
                <span className="badge-number">New Drops</span>
                <span className="badge-label">Every Week</span>
              </div>
              <div className="badge">
                <span className="badge-number">Free</span>
                <span className="badge-label">Store Pickup</span>
              </div>
              <div className="badge">
                <span className="badge-number">Local</span>
                <span className="badge-label">Independent Brand</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-retail">
            <div className="hero-card-header">
              <h2>Featured Looks</h2>
              <p>Highlight a capsule, seasonal drop, or best-sellers that capture your brand.</p>
            </div>
            <div className="hero-grid-retail" id="shop">
              <div className="hero-product hero-product-1">
                <div className="hero-product-label">Everyday Set</div>
              </div>
              <div className="hero-product hero-product-2">
                <div className="hero-product-label">Layering Knits</div>
              </div>
              <div className="hero-product hero-product-3">
                <div className="hero-product-label">Weekend Denim</div>
              </div>
            </div>
            <p className="hero-form-note hero-note-retail">
              Swap these images and labels with real product photos, links, or lookbooks.
            </p>
          </div>
        </div>
      </section>

      <section className="section container features features-retail">
        <div className="section-header">
          <h2>Built for Modern Retail Brands</h2>
          <p>
            Whether you run a single boutique, a multi-location shop, or an online-first brand, this layout 
            gives you a clean home for your story, collections, and in-store details.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-retail">
            <h3>Tell Your Story</h3>
            <p>
              Use simple blocks to share why you started, what you value, and who your pieces are made for.
            </p>
          </div>
          <div className="feature-card feature-card-retail">
            <h3>Highlight Collections</h3>
            <p>
              Feature core categories like denim, outerwear, or home goods with imagery and quick blurbs.
            </p>
          </div>
          <div className="feature-card feature-card-retail">
            <h3>Drive Foot Traffic</h3>
            <p>
              Make your hours, address, parking info, and events easy to find in a few scrolls.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-soft-retail section-gallery-retail">
        <div className="container gallery-layout-retail">
          <div className="gallery-copy-retail">
            <h2>Show the Space, Not Just the Clothes</h2>
            <p>
              Use large, full-bleed imagery to show racks, details, dressing rooms, and the people behind 
              your brand. Acari can rewrite this copy for any retail niche.
            </p>
            <ul className="checklist checklist-retail">
              <li>Swap imagery for clothing, home goods, gifts, or specialty items</li>
              <li>Call out limited runs, local makers, or sustainable materials</li>
              <li>Layer in event nights, pop-ups, or workshops as you grow</li>
            </ul>
          </div>
          <div className="gallery-strip-retail">
            <div className="gallery-card-retail gallery-card-retail-1">
              <div className="gallery-label-retail">In-Store Racks</div>
            </div>
            <div className="gallery-card-retail gallery-card-retail-2">
              <div className="gallery-label-retail">Details &amp; Textures</div>
            </div>
            <div className="gallery-card-retail gallery-card-retail-3">
              <div className="gallery-label-retail">Team &amp; Guests</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
