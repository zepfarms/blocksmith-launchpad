import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-retail">
      <div className="section-header">
        <h1>Visit &amp; Contact</h1>
        <p>
          Make it easy for shoppers to find your location, hours, and how to reach you with questions about 
          sizing, restocks, or special orders.
        </p>
      </div>

      <div className="contact-layout contact-layout-retail">
        <div className="contact-card contact-card-retail">
          <h2>Send a Note</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              How can we help?
              <textarea rows="4" placeholder="Ask about sizing, availability, or anything else." />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-retail btn-full">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-info contact-info-retail">
          <div className="info-block">
            <h3>Store Location</h3>
            <p>
              145 Market Lane<br />
              Your City, ST 12345
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Mon–Fri: 10:00am – 7:00pm<br />
              Sat: 10:00am – 8:00pm<br />
              Sun: 11:00am – 5:00pm
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Email: hello@northatelier.com<br />
              Instagram: @northatelier
            </p>
          </div>
          <div className="info-block">
            <h3>Parking &amp; Pickup</h3>
            <p>
              Use this section for parking instructions, curbside pickup details, and any in-store events 
              shoppers should know about.
            </p>
            <div className="map-placeholder map-placeholder-retail">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
