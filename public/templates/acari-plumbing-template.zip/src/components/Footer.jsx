import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer pl-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo">
            <span className="logo-mark">BP</span>
            <span className="logo-text">
              <span className="logo-primary">BlueWave</span>
              <span className="logo-sub">Plumbing &amp; Drain</span>
            </span>
          </div>
          <p className="footer-text">
            A clean, trustworthy template for plumbing, HVAC, electrical, and home service pros. 
            Swap text, photos, and colors in Acari in just a few prompts.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Office</h4>
          <p className="footer-text">
            789 Service Lane<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Quick Links</h4>
          <ul className="footer-links">
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <a href="#request-service">Request Service</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} BlueWave Plumbing &amp; Drain. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
