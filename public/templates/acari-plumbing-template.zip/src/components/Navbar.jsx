import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar pl-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo">
          <span className="logo-mark">BP</span>
          <span className="logo-text">
            <span className="logo-primary">BlueWave</span>
            <span className="logo-sub">Plumbing &amp; Drain</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
        </nav>
        <a href="#request-service" className="nav-cta">
          24/7 Emergency
        </a>
      </div>
    </header>
  )
}

export default Navbar
