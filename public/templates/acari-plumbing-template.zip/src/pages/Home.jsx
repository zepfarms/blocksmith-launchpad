import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-plumbing">
        <div className="hero-overlay hero-overlay-pl" />
        <div className="container hero-content">
          <div>
            <p className="hero-kicker">Licensed • Insured • 24/7 Emergency Service</p>
            <h1 className="hero-title">
              Your Trusted
              <span className="hero-highlight cool"> Local Plumbing Professionals.</span>
            </h1>
            <p className="hero-subtitle">
              From leaky faucets and clogged drains to water heaters and burst pipes, our certified 
              technicians are on call and on time—every time.
            </p>
            <div className="hero-actions">
              <a href="#request-service" className="btn btn-primary">
                Request Service
              </a>
              <Link to="/services" className="btn btn-secondary">
                View All Services
              </Link>
            </div>
            <div className="hero-badges hero-badges-pl">
              <div className="badge">
                <span className="badge-number">4.9★</span>
                <span className="badge-label">Average Rating</span>
              </div>
              <div className="badge">
                <span className="badge-number">30 Min</span>
                <span className="badge-label">Fast Response*</span>
              </div>
              <div className="badge">
                <span className="badge-number">10+ yrs</span>
                <span className="badge-label">Local Experience</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-pl">
            <div className="hero-card-header">
              <h2>Need Help Right Now?</h2>
              <p>Send a quick request and we&apos;ll call you back within minutes.</p>
            </div>
            <form className="hero-form" id="request-service">
              <label>
                Type of Issue
                <select defaultValue="Emergency Leak">
                  <option>Emergency Leak</option>
                  <option>Drain / Sewer Clog</option>
                  <option>Water Heater Problem</option>
                  <option>Fixture Install</option>
                  <option>Other Plumbing Issue</option>
                </select>
              </label>
              <label>
                Name
                <input type="text" placeholder="Jordan Homeowner" />
              </label>
              <label>
                Phone
                <input type="tel" placeholder="(555) 555-5555" />
              </label>
              <label>
                Address
                <input type="text" placeholder="Street, City" />
              </label>
              <button type="submit" className="btn btn-primary btn-full">
                Request Callback
              </button>
              <p className="hero-form-note">
                For immediate emergencies, call us directly at (555) 555-5555.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features pl-features">
        <div className="section-header">
          <h2>Reliable Service for Every Job</h2>
          <p>
            Use this template for plumbing, HVAC, electrical, or any home service. Highlight your most 
            profitable services and convert visitors into booked jobs.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card pl-feature-card">
            <h3>Emergency Repairs</h3>
            <p>
              Burst pipes, major leaks, and backups handled quickly to protect your home from damage.
            </p>
          </div>
          <div className="feature-card pl-feature-card">
            <h3>Water Heaters</h3>
            <p>
              Installations, replacements, and maintenance for tank and tankless systems.
            </p>
          </div>
          <div className="feature-card pl-feature-card">
            <h3>Drains &amp; Sewers</h3>
            <p>
              Clog clearing, camera inspections, and preventative maintenance to keep things flowing.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-dark pl-section-dark">
        <div className="container split pl-split">
          <div>
            <h2>Professional, Clean, and Respectful</h2>
            <p>
              Customers want to know who is coming into their home. Use this section to introduce your team, 
              explain your guarantees, and build trust with real reviews.
            </p>
            <ul className="checklist cool">
              <li>Upfront, transparent pricing</li>
              <li>Technicians who protect your home and clean up</li>
              <li>Text alerts when your plumber is on the way</li>
            </ul>
          </div>
          <div className="highlight-card pl-highlight">
            <p className="highlight-tag">Great for Service Pros</p>
            <h3>Built to Convert Calls &amp; Form Fills</h3>
            <p>
              Every section is structured so Acari&apos;s AI can easily rewrite it for roofers, electricians, 
              cleaners, landscapers, and more.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
