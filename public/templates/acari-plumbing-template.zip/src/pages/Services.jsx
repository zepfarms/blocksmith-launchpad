import React from 'react'

const Services = () => {
  return (
    <section className="section container services-page">
      <div className="section-header">
        <h1>Plumbing Services</h1>
        <p>
          Customize this page with exactly what your business offers—plumbing, HVAC, electrical, or other 
          home services. Reword everything in seconds with Acari.
        </p>
      </div>

      <div className="services-layout">
        <div className="services-main">
          <h2>Core Plumbing Services</h2>
          <div className="service-group">
            <div className="service-item pl-service-item">
              <h3>Leak Detection &amp; Repair</h3>
              <p>
                From dripping faucets to hidden slab leaks, we use modern tools to find the source and 
                fix it fast.
              </p>
              <p className="service-meta">Upfront pricing • Most repairs same-day</p>
            </div>
            <div className="service-item pl-service-item">
              <h3>Drain Cleaning</h3>
              <p>
                Kitchen, bath, mainline, and sewer drains cleared with professional equipment—not just 
                store-bought chemicals.
              </p>
              <p className="service-meta">Clog clearing • Camera inspections available</p>
            </div>
            <div className="service-item pl-service-item">
              <h3>Water Heater Service</h3>
              <p>
                Repair, replacement, and maintenance for traditional tank and tankless water heaters.
              </p>
              <p className="service-meta">Ask about energy-efficient upgrade options</p>
            </div>
          </div>

          <h2>Installation &amp; Upgrades</h2>
          <div className="service-group">
            <div className="service-item pl-service-item">
              <h3>Fixture Installation</h3>
              <p>
                Sinks, faucets, toilets, tubs, and showers installed cleanly and correctly the first time.
              </p>
            </div>
            <div className="service-item pl-service-item">
              <h3>Remodel &amp; Rough-In</h3>
              <p>
                Bathroom and kitchen remodel rough-ins, basement finishes, and new construction plumbing.
              </p>
            </div>
          </div>
        </div>

        <aside className="services-sidebar">
          <div className="sidebar-card pl-sidebar-card">
            <h3>Service Area</h3>
            <p>
              List the neighborhoods, cities, or regions you serve so customers know they&apos;re in range.
            </p>
          </div>
          <div className="sidebar-card pl-sidebar-card">
            <h3>Membership / Maintenance Plans</h3>
            <p>
              Use this space to promote a yearly maintenance plan, priority scheduling, and special pricing.
            </p>
          </div>
          <div className="sidebar-card pl-sidebar-card">
            <h3>Financing &amp; Warranties</h3>
            <p>
              Highlight financing options for larger projects and warranties on parts and labor.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Services
