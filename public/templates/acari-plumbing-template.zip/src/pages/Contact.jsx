import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page">
      <div className="section-header">
        <h1>Contact &amp; Scheduling</h1>
        <p>
          Make it easy for customers to call, text, or request an appointment online. Plug in your real 
          phone number, address, and any scheduling tools you use.
        </p>
      </div>

      <div className="contact-layout">
        <div className="contact-card">
          <h2>Request an Appointment</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              Phone
              <input type="tel" placeholder="(555) 555-5555" />
            </label>
            <label>
              How can we help?
              <textarea rows="4" placeholder="Tell us about your plumbing issue." />
            </label>
            <button type="submit" className="btn btn-primary btn-full">
              Send Request
            </button>
          </form>
        </div>
        <div className="contact-info">
          <div className="info-block">
            <h3>Office</h3>
            <p>
              789 Service Lane<br />
              Your City, ST 12345
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Mon–Fri: 7:00am – 6:00pm<br />
              Sat: 8:00am – 2:00pm<br />
              Sun: Emergency Only
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Text: (555) 555-5555<br />
              Email: hello@yourserviceco.com
            </p>
          </div>
          <div className="info-block">
            <h3>Map Embed</h3>
            <p>
              Replace this with a Google Maps iframe for your office or service area.
            </p>
            <div className="map-placeholder">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
