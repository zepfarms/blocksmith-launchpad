import React from 'react'
import { NavLink, Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <header className="navbar fit-nav">
      <div className="navbar-inner container">
        <Link to="/" className="logo fit-logo">
          <span className="logo-mark fit-logo-mark">PF</span>
          <span className="logo-text">
            <span className="logo-primary">Pulse</span>
            <span className="logo-sub">Fitness Studio</span>
          </span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/programs" className="nav-link">
            Programs
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Join &amp; Contact
          </NavLink>
        </nav>
        <a href="#trial" className="nav-cta nav-cta-fit">
          Start 7-Day Trial
        </a>
      </div>
    </header>
  )
}

export default Navbar
