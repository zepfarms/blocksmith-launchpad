import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="footer fit-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo fit-logo">
            <span className="logo-mark fit-logo-mark">PF</span>
            <span className="logo-text">
              <span className="logo-primary">Pulse</span>
              <span className="logo-sub">Fitness Studio</span>
            </span>
          </div>
          <p className="footer-text">
            A bold, flexible template for gyms, training studios, CrossFit boxes, yoga spaces, and boutique 
            fitness brands. Swap photos, colors, and programs instantly with Acari.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Location</h4>
          <p className="footer-text">
            800 Strength Avenue<br />
            Your City, ST 12345<br />
            (555) 555-5555
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Explore</h4>
          <ul className="footer-links">
            <li>
              <Link to="/programs">Programs</Link>
            </li>
            <li>
              <Link to="/contact">Join &amp; Contact</Link>
            </li>
            <li>
              <a href="#trial">7-Day Trial</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Pulse Fitness Studio. Built with Acari.ai.</p>
      </div>
    </footer>
  )
}

export default Footer
