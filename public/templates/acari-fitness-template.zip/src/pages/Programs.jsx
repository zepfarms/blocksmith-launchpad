import React from 'react'

const Programs = () => {
  return (
    <section className="section container programs-page programs-page-fit">
      <div className="section-header">
        <h1>Programs</h1>
        <p>
          Use this page to outline how training works at your gym. Group classes, open gym, and coaching 
          into clear, easy-to-understand options.
        </p>
      </div>

      <div className="programs-layout-fit">
        <div className="programs-main-fit">
          <h2>Group Classes</h2>
          <div className="service-group">
            <div className="service-item service-item-fit">
              <h3>Strength Foundations</h3>
              <p>
                A coached class that teaches key lifts, basic movement patterns, and how to train with 
                confidence—perfect for beginners or anyone restarting.
              </p>
              <p className="service-meta">2–3x per week recommended</p>
            </div>
            <div className="service-item service-item-fit">
              <h3>Conditioning / HIIT</h3>
              <p>
                Short, intense intervals with built-in rest to build work capacity without endless cardio.
              </p>
            </div>
            <div className="service-item service-item-fit">
              <h3>Strength &amp; Sweat</h3>
              <p>
                A balanced mix of lifting and conditioning in one session, scaled for multiple experience levels.
              </p>
            </div>
          </div>

          <h2>Coaching &amp; Custom Plans</h2>
          <div className="service-group">
            <div className="service-item service-item-fit">
              <h3>Personal Training</h3>
              <p>
                1:1 sessions focused on your specific goals, with progress tracked and adjusted over time.
              </p>
            </div>
            <div className="service-item service-item-fit">
              <h3>Semi-Private Training</h3>
              <p>
                Train with 2–4 people per coach for a more personalized feel but shared session cost.
              </p>
            </div>
            <div className="service-item service-item-fit">
              <h3>Remote Programming</h3>
              <p>
                Get weekly training plans and check-ins for home or travel workouts outside the gym.
              </p>
            </div>
          </div>

          <h2>Membership Options</h2>
          <div className="service-group">
            <div className="service-item service-item-fit">
              <h3>Unlimited Classes</h3>
              <p>
                Come to any scheduled class each week. Ideal if you like variety and a set routine.
              </p>
            </div>
            <div className="service-item service-item-fit">
              <h3>Class Packs</h3>
              <p>
                5, 10, or 20-class packs for flexible schedules that don&apos;t fit an unlimited membership.
              </p>
            </div>
            <div className="service-item service-item-fit">
              <h3>Open Gym Only</h3>
              <p>
                Access to the space and equipment without classes—perfect for independent lifters.
              </p>
            </div>
          </div>
        </div>

        <aside className="programs-sidebar-fit">
          <div className="sidebar-card sidebar-card-fit">
            <h3>How to Get Started</h3>
            <p>
              Use this area to explain your on-ramp process, intro consults, or required fundamentals sessions 
              before joining regular classes.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-fit">
            <h3>Schedule Snapshot</h3>
            <p>
              Add a simple weekly schedule or link to a live calendar so visitors can see class times at a glance.
            </p>
          </div>
          <div className="sidebar-card sidebar-card-fit">
            <h3>Who It&apos;s For</h3>
            <p>
              Clarify that all ages, experience levels, and body types are welcome—and how you help people scale.
            </p>
          </div>
        </aside>
      </div>
    </section>
  )
}

export default Programs
