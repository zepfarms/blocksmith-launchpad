import React from 'react'

const Contact = () => {
  return (
    <section className="section container contact-page contact-page-fit">
      <div className="section-header">
        <h1>Join &amp; Contact</h1>
        <p>
          Make it easy for future members to ask questions, see where you are, and plan their first visit or 
          consultation.
        </p>
      </div>

      <div className="contact-layout contact-layout-fit">
        <div className="contact-card contact-card-fit">
          <h2>Send a Message</h2>
          <form className="contact-form">
            <label>
              Name
              <input type="text" placeholder="Full name" />
            </label>
            <label>
              Email
              <input type="email" placeholder="you@example.com" />
            </label>
            <label>
              What are you interested in?
              <textarea rows="4" placeholder="Ask about memberships, classes, coaching, or anything else." />
            </label>
            <button type="submit" className="btn btn-primary btn-primary-fit btn-full">
              Submit
            </button>
          </form>
        </div>
        <div className="contact-info contact-info-fit">
          <div className="info-block">
            <h3>Location</h3>
            <p>
              800 Strength Avenue<br />
              Your City, ST 12345
            </p>
          </div>
          <div className="info-block">
            <h3>Hours</h3>
            <p>
              Mon–Fri: 5:30am – 9:00pm<br />
              Sat: 7:00am – 2:00pm<br />
              Sun: Open gym or closed
            </p>
          </div>
          <div className="info-block">
            <h3>Contact</h3>
            <p>
              Phone: (555) 555-5555<br />
              Email: hello@pulsefitness.com<br />
              Instagram: @trainwithpulse
            </p>
          </div>
          <div className="info-block">
            <h3>Parking &amp; First Visit</h3>
            <p>
              Share where to park, how to find your entrance, and what to bring for day one (shoes, towel, etc.).
            </p>
            <div className="map-placeholder map-placeholder-fit">
              Map Placeholder
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
