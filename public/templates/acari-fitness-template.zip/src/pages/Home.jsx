import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      <section className="hero hero-fit">
        <div className="hero-overlay hero-overlay-fit" />
        <div className="container hero-content hero-content-fit">
          <div>
            <p className="hero-kicker hero-kicker-fit">Strength • Classes • Coaching</p>
            <h1 className="hero-title hero-title-fit">
              Train with Intention,
              <span className="hero-highlight hero-highlight-fit"> Show Up Strong.</span>
            </h1>
            <p className="hero-subtitle hero-subtitle-fit">
              Small-group classes, open gym, and 1:1 coaching in a space built for real people—not fitness 
              influencers. Start where you are, progress with a plan.
            </p>
            <div className="hero-actions">
              <a href="#trial" className="btn btn-primary btn-primary-fit">
                Start 7-Day Trial
              </a>
              <Link to="/programs" className="btn btn-secondary btn-secondary-fit">
                View Programs
              </Link>
            </div>
            <div className="hero-badges hero-badges-fit">
              <div className="badge">
                <span className="badge-number">All Levels</span>
                <span className="badge-label">Beginner-Friendly</span>
              </div>
              <div className="badge">
                <span className="badge-number">5:30am–9pm</span>
                <span className="badge-label">Weekday Hours</span>
              </div>
              <div className="badge">
                <span className="badge-number">Community</span>
                <span className="badge-label">Not Crowded Chains</span>
              </div>
            </div>
          </div>
          <div className="hero-card hero-card-fit">
            <div className="hero-card-header">
              <h2>Try Us for 7 Days</h2>
              <p>Fill this out to claim a no-pressure 7-day pass. We&apos;ll follow up with next steps.</p>
            </div>
            <form className="hero-form" id="trial">
              <label>
                Name
                <input type="text" placeholder="Full name" />
              </label>
              <label>
                Email
                <input type="email" placeholder="you@example.com" />
              </label>
              <label>
                Goal
                <select defaultValue="Get Stronger">
                  <option>Get Stronger</option>
                  <option>Lose Weight</option>
                  <option>Build Muscle</option>
                  <option>Move Pain-Free</option>
                  <option>General Fitness</option>
                </select>
              </label>
              <label>
                Preferred Time
                <select defaultValue="Early Morning">
                  <option>Early Morning</option>
                  <option>Midday</option>
                  <option>Evening</option>
                  <option>Weekends</option>
                </select>
              </label>
              <button type="submit" className="btn btn-primary btn-primary-fit btn-full">
                Claim 7-Day Trial
              </button>
              <p className="hero-form-note">
                We&apos;ll reach out with class recommendations and how to check in for your first visit.
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className="section container features features-fit">
        <div className="section-header">
          <h2>Built for Real Life, Not Just Highlight Reels</h2>
          <p>
            Use this layout for strength gyms, HIIT studios, yoga spaces, CrossFit boxes, or hybrid clubs. 
            Acari can rewrite each block in your brand&apos;s voice.
          </p>
        </div>
        <div className="feature-grid">
          <div className="feature-card feature-card-fit">
            <h3>Coached Classes</h3>
            <p>
              Small-group sessions with clear instruction, progressions, and form checks in every class.
            </p>
          </div>
          <div className="feature-card feature-card-fit">
            <h3>Open Gym Access</h3>
            <p>
              Drop in on your schedule with full access to racks, turf, conditioning gear, and more.
            </p>
          </div>
          <div className="feature-card feature-card-fit">
            <h3>Personal Coaching</h3>
            <p>
              1:1 or small semi-private training tailored to your goals, history, and experience level.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-soft-fit section-gallery-fit">
        <div className="container gallery-layout-fit">
          <div className="gallery-copy-fit">
            <h2>Show the Space &amp; the People</h2>
            <p>
              Swap these photos with your own training floor, class moments, and coaching staff. Let future 
              members see who they&apos;re walking in to meet.
            </p>
            <ul className="checklist checklist-fit">
              <li>Highlight equipment zones, class styles, and unique features</li>
              <li>Call out beginner-friendly options and on-ramp programs</li>
              <li>Use this area to make your community feel welcoming, not intimidating</li>
            </ul>
          </div>
          <div className="gallery-strip-fit">
            <div className="gallery-card-fit gallery-card-fit-1">
              <div className="gallery-label-fit">Training Floor</div>
            </div>
            <div className="gallery-card-fit gallery-card-fit-2">
              <div className="gallery-label-fit">Classes in Motion</div>
            </div>
            <div className="gallery-card-fit gallery-card-fit-3">
              <div className="gallery-label-fit">Coaches &amp; Community</div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home
